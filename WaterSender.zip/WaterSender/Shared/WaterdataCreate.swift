import Foundation

// ⚠️ If your main app already defines these types, use YOUR versions instead,
// so the enum raw values and number types match exactly on both sides.

enum WaterSource: String, Codable, CaseIterable, Identifiable {
    case dealLake
    var id: String { rawValue }
}

enum Weather: String, Codable, CaseIterable, Identifiable {
    case clear, partlyCloudy, overcast, rain, snow
    var id: String { rawValue }
}

struct WaterdataCreate: Codable, Equatable {
    var source: WaterSource
    var station: String
    var conductivity: Double      // µS/cm
    var waterTemperature: Double  // °C
    var dissolvedOxygen: Double   // mg/L
    var saturationDO: Double      // %
    var ph: Double
    var turbidity: Double         // NTU
    var pastWeather: Weather
    var currWeather: Weather
    var fieldMembers: String
}

extension WaterdataCreate {
    // Placeholder until readings come from the Bluetooth device.
    static let sample = WaterdataCreate(
        source: .dealLake,
        station: "Station 1",
        conductivity: 450,
        waterTemperature: 18.5,
        dissolvedOxygen: 8.2,
        saturationDO: 92,
        ph: 7.4,
        turbidity: 3.1,
        pastWeather: .clear,
        currWeather: .overcast,
        fieldMembers: "Test User"
    )

    // Sample with slightly varied numbers, to mimic new sensor readings.
    static func randomized() -> WaterdataCreate {
        func r(_ v: Double, _ spread: Double) -> Double {
            ((v + Double.random(in: -spread...spread)) * 10).rounded() / 10
        }
        var d = sample
        d.conductivity     = (450 + Double.random(in: -40...40)).rounded()
        d.waterTemperature = r(18.5, 2)
        d.dissolvedOxygen  = r(8.2, 1)
        d.saturationDO     = (92 + Double.random(in: -5...5)).rounded()
        d.ph               = r(7.4, 0.4)
        d.turbidity        = r(3.1, 1)
        return d
    }
}

extension JSONEncoder {
    static let ble = JSONEncoder()
}

extension JSONDecoder {
    static let ble = JSONDecoder()
}
