import SwiftUI

struct SenderView: View {
    @StateObject private var ble = BLESender()
    @State private var data = WaterdataCreate.sample
    @State private var lastJSON = ""

    var body: some View {
        NavigationStack {
            Form {
                Section("Status") {
                    Label(ble.status, systemImage: ble.isSubscribed ? "link" : "antenna.radiowaves.left.and.right")
                }

                Section("Site") {
                    Picker("Source", selection: $data.source) {
                        ForEach(WaterSource.allCases) { Text($0.rawValue).tag($0) }
                    }
                    TextField("Station", text: $data.station)
                    TextField("Field members", text: $data.fieldMembers)
                }

                Section("Readings") {
                    numberRow("Conductivity (µS/cm)", $data.conductivity)
                    numberRow("Water temp (°C)", $data.waterTemperature)
                    numberRow("Dissolved O₂ (mg/L)", $data.dissolvedOxygen)
                    numberRow("DO saturation (%)", $data.saturationDO)
                    numberRow("pH", $data.ph)
                    numberRow("Turbidity (NTU)", $data.turbidity)
                }

                Section("Weather") {
                    Picker("Past", selection: $data.pastWeather) {
                        ForEach(Weather.allCases) { Text($0.rawValue).tag($0) }
                    }
                    Picker("Current", selection: $data.currWeather) {
                        ForEach(Weather.allCases) { Text($0.rawValue).tag($0) }
                    }
                }

                Section {
                    Button("Send JSON") { send() }
                        .disabled(!ble.isSubscribed)
                    Button("Randomize readings") { data = .randomized() }
                    Button("Reset to sample") { data = .sample }
                }

                if !lastJSON.isEmpty {
                    Section("Last sent JSON") {
                        Text(lastJSON).font(.system(.footnote, design: .monospaced))
                    }
                }
            }
            .navigationTitle("Water Sender")
        }
    }

    private func send() {
        ble.send(data)
        let pretty = JSONEncoder()
        pretty.outputFormatting = [.prettyPrinted, .sortedKeys]
        if let json = try? pretty.encode(data) {
            lastJSON = String(decoding: json, as: UTF8.self)
        }
    }

    private func numberRow(_ label: String, _ value: Binding<Double>) -> some View {
        HStack {
            Text(label)
            Spacer()
            TextField(label, value: value, format: .number)
                .multilineTextAlignment(.trailing)
                .keyboardType(.decimalPad)
                .frame(maxWidth: 100)
        }
    }
}
