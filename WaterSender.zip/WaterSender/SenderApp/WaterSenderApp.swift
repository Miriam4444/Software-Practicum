import SwiftUI

@main
struct WaterSenderApp: App {
    var body: some Scene {
        WindowGroup { SenderView() }
    }
}
