import SwiftUI

struct ReceiverView: View {
    @StateObject private var ble = BLEReceiver()

    var body: some View {
        NavigationStack {
            List {
                Section("Status") { Text(ble.status) }

                if !ble.lastRawJSON.isEmpty {
                    Section("Last raw JSON") {
                        Text(ble.lastRawJSON).font(.system(.footnote, design: .monospaced))
                    }
                }

                Section("Readings") {
                    if ble.messages.isEmpty {
                        Text("Nothing yet").foregroundStyle(.secondary)
                    }
                    ForEach(Array(ble.messages.enumerated()), id: \.offset) { _, d in
                        VStack(alignment: .leading, spacing: 4) {
                            Text("\(d.source.rawValue) · \(d.station)").font(.headline)
                            Text("Temp \(d.waterTemperature, specifier: "%.1f")°C · pH \(d.ph, specifier: "%.1f") · Turb \(d.turbidity, specifier: "%.1f") NTU")
                            Text("Cond \(d.conductivity, specifier: "%.0f") µS/cm · DO \(d.dissolvedOxygen, specifier: "%.1f") mg/L (\(d.saturationDO, specifier: "%.0f")%)")
                            Text("Weather: \(d.pastWeather.rawValue) → \(d.currWeather.rawValue) · \(d.fieldMembers)")
                                .font(.caption).foregroundStyle(.secondary)
                        }
                    }
                }
            }
            .navigationTitle("Receiver")
        }
    }
}
